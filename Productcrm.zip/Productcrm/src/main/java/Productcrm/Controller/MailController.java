package Productcrm.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import Productcrm.Service.*;
import Productcrm.model.Product;
import jakarta.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.bind.annotation.RequestMethod;
@Controller
public class MailController {

	@Autowired
	 private ProductService ps;
	
	@RequestMapping("/")
	public String i(Model m) {
		List<Product> ap = ps.allProducts();
		m.addAttribute("Ap",ap);
		return "index";
	}
	
	
	
	@RequestMapping("/add")
	public String addProduct(Model m) {
		m.addAttribute("title","Product App");
		return "add-product";
	}

	
	
	@RequestMapping(value="/handleform" ,method=RequestMethod.POST)
	public RedirectView handleP(@ModelAttribute Product p,HttpServletRequest req) {
		RedirectView rv=new RedirectView();
		ps.createProduct(p);
		rv.setUrl(req.getContextPath()+"/");
		return rv;
	}
	
	
	
	@RequestMapping("/delete/{id}")
	public RedirectView deleete(@PathVariable("id") int id,HttpServletRequest req) {
		RedirectView rv=new RedirectView();
		ps.deleteP(id);
		rv.setUrl(req.getContextPath()+"/");
		return rv;
	}
	
	
	
	@RequestMapping("/update/{id}")
	public String update(@PathVariable("id") int id,Model m) {
	
//		rv.setUrl(req.getContextPath()+"/");
		Product p = ps.getP(id);
		m.addAttribute("product",p);
		return"update";
		
	}
}
