package Productcrm.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Productcrm.dao.Productdao;
import Productcrm.model.Product;

@Service
public class ProductService {

	@Autowired
	private Productdao pd;
	
	public void createProduct(Product p) {
		 this.pd.createProduct(p);
	}
	
	public List<Product> allProducts(){
		return this.pd.getAllProducts();
	}
	
	public void deleteP(int id) {
		 this.pd.deleteProduct(id);
	}
	public Product getP(int id) {
		Product p = this.pd.getProduct(id);
		return p;
	}
}
