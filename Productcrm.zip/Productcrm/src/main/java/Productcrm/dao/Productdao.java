package Productcrm.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import Productcrm.model.Product;

@Repository
public class Productdao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public Productdao(HibernateTemplate hibernateTemplate) {
		super();
		this.hibernateTemplate = hibernateTemplate;
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Transactional
	public  void createProduct(Product p) {
		this.hibernateTemplate.saveOrUpdate(p);
	}
	
	public List<Product> getAllProducts(){
		List<Product> ps = this.hibernateTemplate.loadAll(Product.class);
		return ps;
	}
	
//	delete single product
	@Transactional
	public void deleteProduct(int id) {
		
		Product p = this.hibernateTemplate.load(Product.class,id);
		this.hibernateTemplate.delete(p);
	}
	
	//get Single Product
	
	public Product getProduct(int id) {
		Product p = this.hibernateTemplate.get(Product.class, id);
		return p;
	}
	
}
